# Changelog

## [1.0.0] - 2025-02-13
### Added
- Initial release of the Prompt Generator.
- Supports saving and loading previous prompts.
- GitHub Actions for automation.
- Export prompts to .txt files.
- Batch prompt generation mode.
